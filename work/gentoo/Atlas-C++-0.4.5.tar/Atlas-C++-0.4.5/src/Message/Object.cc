// This file may be redistributed and modified only under the terms of
// the GNU Lesser General Public License (See COPYING for details).
// Copyright (C) 2000-2001 Stefanus Du Toit, Karsten-O. Laux, Alistair Riddoch

#include "Object.h"

namespace Atlas { namespace Message {

} } //namespace Atlas::Message
