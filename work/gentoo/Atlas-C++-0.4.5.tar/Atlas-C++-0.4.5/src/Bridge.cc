// This file may be redistributed and modified only under the terms of
// the GNU Lesser General Public License (See COPYING for details).
// Copyright (C) 2000 Michael Day

#include "Bridge.h"

using Atlas::Bridge;

Bridge::Map Bridge::MapBegin;
Bridge::List Bridge::ListBegin;
