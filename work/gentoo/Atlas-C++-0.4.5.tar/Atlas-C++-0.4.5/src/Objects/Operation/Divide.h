// This file may be redistributed and modified only under the terms of
// the GNU Lesser General Public License (See COPYING for details).
// Copyright 2000-2001 Stefanus Du Toit and Alistair Riddoch.
// Automatically generated using gen_cc.py.

#ifndef ATLAS_OBJECTS_OPERATION_DIVIDE_H
#define ATLAS_OBJECTS_OPERATION_DIVIDE_H

#include "Create.h"


namespace Atlas { namespace Objects { namespace Operation { 

/** Divide existing object into pieces.

One of the pieces might be original object modified.

*/
class Divide : public Create
{
public:
    /// Construct a Divide class definition.
    Divide();
  protected:
    Divide(const std::string&,const std::string&);
  public:
    /// Default destructor.
    virtual ~Divide() { }

    /// Create a new instance of Divide.
    static Divide Instantiate();

protected:

};

} } } // namespace Atlas::Objects::Operation

#endif // ATLAS_OBJECTS_OPERATION_DIVIDE_H
