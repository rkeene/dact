// This file may be redistributed and modified only under the terms of
// the GNU Lesser General Public License (See COPYING for details).
// Copyright 2000-2001 Stefanus Du Toit and Alistair Riddoch.
// Automatically generated using gen_cc.py.

#ifndef ATLAS_OBJECTS_OPERATION_PERCEPTION_H
#define ATLAS_OBJECTS_OPERATION_PERCEPTION_H

#include "Info.h"


namespace Atlas { namespace Objects { namespace Operation { 

/** Character perceives something.

Base operator for all kind of perceptions

*/
class Perception : public Info
{
public:
    /// Construct a Perception class definition.
    Perception();
  protected:
    Perception(const std::string&,const std::string&);
  public:
    /// Default destructor.
    virtual ~Perception() { }

    /// Create a new instance of Perception.
    static Perception Instantiate();

protected:

};

} } } // namespace Atlas::Objects::Operation

#endif // ATLAS_OBJECTS_OPERATION_PERCEPTION_H
