// This file may be redistributed and modified only under the terms of
// the GNU Lesser General Public License (See COPYING for details).
// Copyright (C) 2001 Stefanus Du Toit

#ifndef ATLAS_CODEC_IMPL_H
#define ATLAS_CODEC_IMPL_H

#include "Codec.h"

namespace Atlas {

template <class Stream> Codec<Stream>::~Codec()
{
}

} // Atlas namespace

#endif

