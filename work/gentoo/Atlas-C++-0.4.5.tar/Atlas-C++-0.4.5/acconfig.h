#undef PACKAGE
#undef VERSION

/* Define to `int' if <sys/types.h> doesn't have this */
#undef socklen_t
